﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe //Implement most of the code here
{
    public partial class Form1 : Form
    {
        bool isThereAWinner = false;
        bool turn = false; // True = X turn //False = 0 turn
        int turnCount = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Game designed by Anghel Matei", "Tic Tac Toe About");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonClick(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            b.Text = "0";
            turn = !turn;
            b.Enabled = false;
            turnCount++;
            checkForWinner();
            if (!isThereAWinner)
            {
                AIturn();
                turnCount++;
                turn = !turn;
                checkForWinner();
            }
            
        }

        private void checkForWinner()
        {
            
            
            //Horizontal Check
            if ((A1.Text == A2.Text) && (A2.Text == A3.Text) && (!A1.Enabled))
                isThereAWinner = true;
            else if ((B1.Text == B2.Text) && (B2.Text == B3.Text) && (!B1.Enabled))
                isThereAWinner = true;
            else if ((C1.Text == C2.Text) && (C2.Text == C3.Text) && (!C1.Enabled))
                isThereAWinner = true;

            //Vertical Check
            else if ((A1.Text == B1.Text) && (B1.Text == C1.Text) && (!A1.Enabled))
                isThereAWinner = true;
            else if ((A2.Text == B2.Text) && (B2.Text == C2.Text) && (!A2.Enabled))
                isThereAWinner = true;
            else if ((A3.Text == B3.Text) && (B3.Text == C3.Text) && (!A3.Enabled))
                isThereAWinner = true;

            //Diagonal Check
            else if ((A1.Text == B2.Text) && (B2.Text == C3.Text) && (!A1.Enabled))
                isThereAWinner = true;
            else if ((A3.Text == B2.Text) && (B2.Text == C1.Text) && (!A3.Enabled))
                isThereAWinner = true;

            if (isThereAWinner)
            {
                disableButtons();
                String winner = "";
                if (turn)
                    winner = "0";
                else winner = "X";
                MessageBox.Show(winner + " wins the match! \n Congratulations! \n But the last one who beat me was Cami", "Yaay");
            }
            else
            {
                if(turnCount == 9)
                {
                    MessageBox.Show("Nobody wins the match!  \n Draw!", "Bummer!");
                    isThereAWinner = true;
                }
                    

            }
        }

        private void disableButtons()
        {

            try // Runtime error because menu is converted to button
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = false;
                }
            }
            catch { }
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            turn = false;
            turnCount = 0;
            isThereAWinner = false;

            try // Runtime error because menu is converted to button
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = Enabled;
                    b.Text = "";
                }
            }
            catch { }
        }

        private void AIturn()
        {
            //Try to win
            // Horizontal check
            //First line
            if ((A1.Text == A2.Text) && (A2.Text == "X") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A2.Text == A3.Text) && (A3.Text == "X") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if ((A1.Text == A3.Text) && (A3.Text == "X") && (A2.Enabled))
            {
                A2.Text = "X";
                A2.Enabled = false;
            }
            //Second line
            else if ((B1.Text == B2.Text) && (B2.Text == "X") && (B3.Enabled))
            {
                B3.Text = "X";
                B3.Enabled = false;
            }
            else if ((B2.Text == B3.Text) && (B3.Text == "X") && (B1.Enabled))
            {
                B1.Text = "X";
                B1.Enabled = false;
            }
            else if ((B1.Text == B3.Text) && (B3.Text == "X") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Third line
            else if ((C1.Text == C2.Text) && (C2.Text == "X") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((C2.Text == C3.Text) && (C3.Text == "X") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((C1.Text == C3.Text) && (C3.Text == "X") && (C2.Enabled))
            {
                C2.Text = "X";
                C2.Enabled = false;
            }
            //Vertical check
            //First columnn
            else if ((A1.Text == B1.Text) && (B1.Text == "X") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((B1.Text == C1.Text) && (C1.Text == "X") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if ((A1.Text == C1.Text) && (C1.Text == "X") && (B1.Enabled))
            {
                B1.Text = "X";
                B1.Enabled = false;
            }
            //Second column
            else if ((A2.Text == B2.Text) && (B2.Text == "X") && (C2.Enabled))
            {
                C2.Text = "X";
                C2.Enabled = false;
            }
            else if ((B2.Text == C2.Text) && (C2.Text == "X") && (A2.Enabled))
            {
                A2.Text = "X";
                A2.Enabled = false;
            }
            else if ((A2.Text == C2.Text) && (C2.Text == "X") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Third column
            else if ((A3.Text == B3.Text) && (B3.Text == "X") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((B3.Text == C3.Text) && (C3.Text == "X") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A3.Text == C3.Text) && (C3.Text == "X") && (B3.Enabled))
            {
                B3.Text = "X";
                B3.Enabled = false;
            }
            //Diagonal check
            //First diagonal
            else if ((A1.Text == B2.Text) && (B2.Text == "X") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((B2.Text == C3.Text) && (C3.Text == "X") && (A1.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A1.Text == C3.Text) && (C3.Text == "X") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Second diagonal
            else if ((A3.Text == B2.Text) && (B2.Text == "X") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((B2.Text == C1.Text) && (C1.Text == "X") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A3.Text == C1.Text) && (C1.Text == "X") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Try to block
            // Horizontal check
            //First line
            else if ((A1.Text == A2.Text) && (A2.Text == "0") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A2.Text == A3.Text) && (A3.Text == "0") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if ((A1.Text == A3.Text) && (A3.Text == "0") && (A2.Enabled))
            {
                A2.Text = "X";
                A2.Enabled = false;
            }
            //Second line
            else if ((B1.Text == B2.Text) && (B2.Text == "0") && (B3.Enabled))
            {
                B3.Text = "X";
                B3.Enabled = false;
            }
            else if ((B2.Text == B3.Text) && (B3.Text == "0") && (B1.Enabled))
            {
                B1.Text = "X";
                B1.Enabled = false;
            }
            else if ((B1.Text == B3.Text) && (B3.Text == "0") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Third line
            else if ((C1.Text == C2.Text) && (C2.Text == "0") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((C2.Text == C3.Text) && (C3.Text == "0") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((C1.Text == C3.Text) && (C3.Text == "0") && (C2.Enabled))
            {
                C2.Text = "X";
                C2.Enabled = false;
            }
            //Vertical check
            //First columnn
            else if ((A1.Text == B1.Text) && (B1.Text == "0") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((B1.Text == C1.Text) && (C1.Text == "0") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if ((A1.Text == C1.Text) && (C1.Text == "0") && (B1.Enabled))
            {
                B1.Text = "X";
                B1.Enabled = false;
            }
            //Second column
            else if ((A2.Text == B2.Text) && (B2.Text == "0") && (C2.Enabled))
            {
                C2.Text = "X";
                C2.Enabled = false;
            }
            else if ((B2.Text == C2.Text) && (C2.Text == "0") && (A2.Enabled))
            {
                A2.Text = "X";
                A2.Enabled = false;
            }
            else if ((A2.Text == C2.Text) && (C2.Text == "0") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Third column
            else if ((A3.Text == B3.Text) && (B3.Text == "0") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((B3.Text == C3.Text) && (C3.Text == "0") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A3.Text == C3.Text) && (C3.Text == "0") && (B3.Enabled))
            {
                B3.Text = "X";
                B3.Enabled = false;
            }
            //Diagonal check
            //First diagonal
            else if ((A1.Text == B2.Text) && (B2.Text == "0") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((B2.Text == C3.Text) && (C3.Text == "0") && (A1.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A1.Text == C3.Text) && (C3.Text == "0") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            //Second diagonal
            else if ((A3.Text == B2.Text) && (B2.Text == "0") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((B2.Text == C1.Text) && (C1.Text == "0") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((A3.Text == C1.Text) && (C1.Text == "0") && (B2.Enabled))
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            // Make random X
            // Try for center
            // Middle
            else if(B2.Enabled)
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            // Strategia Cami
            else if((B2.Text == "X") && (A2.Enabled))
            {
                A2.Text = "X";
                A2.Enabled = false;
            }
            else if ((B2.Text == "X") && (B1.Enabled))
            {
                B1.Text = "X";
                B1.Enabled = false;
            }
            else if ((B2.Text == "X") && (C2.Enabled))
            {
                C2.Text = "X";
                C2.Enabled = false;
            }
            else if ((B2.Text == "X") && (B3.Enabled))
            {
                B3.Text = "X";
                B3.Enabled = false;
            }
            // Check corners
            else if ((A1.Text == "0") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if ((A3.Text == "0") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((C1.Text == "0") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((C3.Text == "0") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            //Side A2 with 0
            else if((A2.Text == "0") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if ((A2.Text == "0") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            //Side B3 with 0
            else if ((B3.Text == "0") && (A3.Enabled))
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if ((B3.Text == "0") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            //Side C2 with 0
            else if ((C2.Text == "0") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if ((C2.Text == "0") && (C3.Enabled))
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            // Side B1 with 0
            else if ((B1.Text == "0") && (A1.Enabled))
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if ((B1.Text == "0") && (C1.Enabled))
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            // Try go for the corners
            else if(A1.Enabled)
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if (A3.Enabled)
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if (C1.Enabled)
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if (C3.Enabled)
            {
                C3.Text = "X";
                C3.Enabled = false;
            }
            else if(A1.Enabled)
            {
                A1.Text = "X";
                A1.Enabled = false;
            }
            else if (A2.Enabled)
            {
                A2.Text = "X";
                A2.Enabled = false;
            }
            else if (A3.Enabled)
            {
                A3.Text = "X";
                A3.Enabled = false;
            }
            else if (B1.Enabled)
            {
                B1.Text = "X";
                B1.Enabled = false;
            }
            else if (B2.Enabled)
            {
                B2.Text = "X";
                B2.Enabled = false;
            }
            else if (B3.Enabled)
            {
                B3.Text = "X";
                B3.Enabled = false;
            }
            else if (C1.Enabled)
            {
                C1.Text = "X";
                C1.Enabled = false;
            }
            else if (C2.Enabled)
            {
                C2.Text = "X";
                C2.Enabled = false;
            }
            else if (C3.Enabled)
            {
                C3.Text = "X";
                C3.Enabled = false;
            }



        }
    }
}
